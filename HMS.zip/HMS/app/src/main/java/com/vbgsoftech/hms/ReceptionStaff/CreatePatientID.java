package com.vbgsoftech.hms.ReceptionStaff;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.vbgsoftech.hms.R;

public class CreatePatientID extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_patient_i_d);

        // not done now
    }
}
