package com.vbgsoftech.hms.Staff;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.vbgsoftech.hms.R;

public class ViewSalary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_salary_staff);
    }
}
