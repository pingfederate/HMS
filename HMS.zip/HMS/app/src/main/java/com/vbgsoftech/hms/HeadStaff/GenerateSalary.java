package com.vbgsoftech.hms.HeadStaff;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.vbgsoftech.hms.R;

public class GenerateSalary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_salary);
    }
}
